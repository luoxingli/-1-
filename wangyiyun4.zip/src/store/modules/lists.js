export default {
    state: {
        lists:[
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
            {top:"与火星孩子的对话",path:"http://s3.music.126.net/mobile-new/img/index_icon_2x.png?5207a28c3767992ca4bb6d4887c74880=",bottom:"华晨宇-与火星孩子的对话"},
        ]
    },
    mutations: {
        goplay(){
            this.$router.push("/playMusic")
        }
    },
    actions: {},
    modules: {
    }
  }