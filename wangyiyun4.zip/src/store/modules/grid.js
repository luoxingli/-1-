export default {
    state: {
        lists:[
            {path:"http://p2.music.126.net/FlPMK7ifTw5Bw75nyXWqSg==/109951164475215683.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"71.3万",text:"在孤独难捱的日子里，哪首歌曾经陪伴过你?"},
            {path:"http://p2.music.126.net/MnRunqCGpe6eNvEhVexGLA==/109951164494292652.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"33195",text:"德语男声 | 予我浩瀚星辰"},
            {path:"http://p2.music.126.net/--0RwiVTJfJ0gNr8HloWOQ==/109951164228101080.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"4421.3万",text:"2019最新热歌分享（持续更新）"},
            {path:"http://p2.music.126.net/Fs0DjAvcAAyAZa1dgXzFfQ==/109951163571833739.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"1.3亿",text:"听说你也在找好听的华语歌"},
            {path:"http://p2.music.126.net/0CqmyIQ7-pFoohrSvHWolw==/109951164271725693.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"774.8万",text:"丧丧丧//沉默是最大的哭声我希望你能懂"},
            {path:"http://p2.music.126.net/hB4lqF-LiFYx_yvbChb7gg==/109951163754920641.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",num:"8879万",text:"700首流行经典老歌| 80/90/00后KTV怀旧珍藏"},
        ]
    },
    mutations: {
        go(){
            this.$router.push("/zhuanji")
        }
    },
    actions: {},
    modules: {
    }
  }