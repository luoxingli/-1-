export default {
    state: {
        lists:[
            {
            bpath:"http://img3.imgtn.bdimg.com/it/u=175919244,932448081&fm=26&gp=0.jpg",
            spath:"http://img0.imgtn.bdimg.com/it/u=410750609,2447567977&fm=26&gp=0.jpg",
            showbtn:true,focustext:"关注",name:"鱿鱼",fans:"481.2万粉丝",
            htag1:"有的人看着风光",htag2:"其实连狗都没有...",looked:"640",great:"11901",new:"26.6万"
            },
            {
            bpath:"http://img0.imgtn.bdimg.com/it/u=4073821464,3431246218&fm=26&gp=0.jpg",
            spath:"http://img0.imgtn.bdimg.com/it/u=410750609,2447567977&fm=26&gp=0.jpg",
            showbtn:true,focustext:"关注",name:"鱿鱼",fans:"481.2万粉丝",
            htag1:"有的人看着风光",htag2:"其实连狗都没有...",looked:"640",great:"11901",new:"26.6万"
            },
            {
            bpath:"http://img3.imgtn.bdimg.com/it/u=175919244,932448081&fm=26&gp=0.jpg",
            spath:"http://img0.imgtn.bdimg.com/it/u=410750609,2447567977&fm=26&gp=0.jpg",
            showbtn:true,focustext:"关注",name:"鱿鱼",fans:"481.2万粉丝",
            htag1:"有的人看着风光",htag2:"其实连狗都没有...",looked:"640",great:"11901",new:"26.6万"
            },
        ]
    },
    mutations: {        
        focus(state){
            this.lists=state;
            // window.console.log(this.lists)
        }
        
    },
    actions: {},
    modules: {
     
    }
  }