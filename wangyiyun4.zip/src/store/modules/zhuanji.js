export default {
    state: {
        num:"197.9万",
        li:"最佳制作提名",
        title:"第62届格莱美提名名单",
        path:"http://p2.music.126.net/FlPMK7ifTw5Bw75nyXWqSg==/109951164475215683.webp?imageView&thumbnail=246x0&quality=75&tostatic=0&type=webp",
        editor:"OneDeive"
    },
    mutations: {
        back(){
            this.$router.push("/gg")
        }
    },
    actions: {},
    modules: {
    }
  }