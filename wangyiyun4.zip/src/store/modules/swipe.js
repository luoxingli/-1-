export default {
    state: {
        list:[
            {path:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfqfsB1jucsMXenzXUYXu59ewZaRpa2ZTHb7mrMAvFKNwL0kGhvQ&s"},
            {path:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfqfsB1jucsMXenzXUYXu59ewZaRpa2ZTHb7mrMAvFKNwL0kGhvQ&s"},
            {path:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfqfsB1jucsMXenzXUYXu59ewZaRpa2ZTHb7mrMAvFKNwL0kGhvQ&s"},
            {path:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfqfsB1jucsMXenzXUYXu59ewZaRpa2ZTHb7mrMAvFKNwL0kGhvQ&s"},
            {path:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfqfsB1jucsMXenzXUYXu59ewZaRpa2ZTHb7mrMAvFKNwL0kGhvQ&s"},
        ]
    },
    mutations: {
        go(){
            this.$router.push("/zhuanji")
        }
    },
    actions: {},
    modules: {
    }
  }