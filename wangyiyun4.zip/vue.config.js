module.exports = {
    devServer:{
        host:"0.0.0.0",  //ip
        port:8081 //端口
    },
    lintOnSave:false  //取消eslint验证
}